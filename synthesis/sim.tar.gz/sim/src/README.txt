Verilog standard cells libs location

/CMC/kits/cadence/GPDK045/gsclib045_all_v4.4/gsclib045/verilog
